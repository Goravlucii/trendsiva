import sqlite3
import json
from flask import Flask, jsonify, g, request, render_template, redirect, url_for
from flask_cors import CORS

app = Flask(__name__)
CORS(app) # Enable CORS for all routes

DATABASE = 'database.db'

def get_db():
    """Connects to the specific database."""
    db = getattr(g, '_database', None)
    if db is None:
        db = g._database = sqlite3.connect(DATABASE)
        db.row_factory = sqlite3.Row # This allows access to columns by name
    return db

@app.teardown_appcontext
def close_connection(exception):
    """Closes the database connection at the end of the request."""
    db = getattr(g, '_database', None)
    if db is not None:
        db.close()

def init_db():
    """Initializes the database schema and populates with initial data."""
    with app.app_context():
        db = get_db()
        cursor = db.cursor()

        # Drop tables if they exist (for easy re-initialization during development)
        cursor.execute("DROP TABLE IF EXISTS global_settings")
        cursor.execute("DROP TABLE IF EXISTS client_logos")
        cursor.execute("DROP TABLE IF EXISTS ai_advantages")
        cursor.execute("DROP TABLE IF EXISTS services")
        cursor.execute("DROP TABLE IF EXISTS case_studies")
        cursor.execute("DROP TABLE IF EXISTS testimonials")

        # Create tables
        cursor.execute("""
            CREATE TABLE global_settings (
                id INTEGER PRIMARY KEY,
                hero_typed_words TEXT,
                hero_sub_headline TEXT,
                hero_video_url TEXT,
                footer_address TEXT,
                footer_email TEXT,
                footer_phone TEXT,
                footer_linkedin TEXT,
                footer_twitter TEXT,
                footer_logo_light TEXT
            )
        """)
        cursor.execute("""
            CREATE TABLE client_logos (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT,
                image_url TEXT
            )
        """)
        cursor.execute("""
            CREATE TABLE ai_advantages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT,
                description TEXT,
                icon_url TEXT
            )
        """)
        cursor.execute("""
            CREATE TABLE services (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT,
                description TEXT,
                icon_url TEXT
            )
        """)
        cursor.execute("""
            CREATE TABLE case_studies (
                id TEXT PRIMARY KEY, -- Use TEXT for custom IDs like 'ecom', 'saas'
                title TEXT,
                industry TEXT,
                challenge TEXT,
                solution TEXT,
                results_text TEXT,
                results_charts_html TEXT,
                testimonial TEXT,
                cite TEXT,
                thumbnail_url TEXT
            )
        """)
        cursor.execute("""
            CREATE TABLE testimonials (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                quote TEXT,
                client_name TEXT,
                client_title_location TEXT,
                photo_url TEXT
            )
        """)
        db.commit()

        # --- Initial Data Population ---
        # This is where you will make changes to your content until the UI is built!
        initial_data = {
            "global_settings": {
                "hero_typed_words": json.dumps(["Accelerate", "Amplify", "Transform", "Optimize", "Scale"]),
                "hero_sub_headline": "Data-driven, AI-powered digital marketing strategies for ambitious US brands.",
                "hero_video_url": "https://assets.mixkit.co/videos/preview/mixkit-abstract-particles-moving-4787-large.mp4",
                "footer_address": "123 AI Boulevard, Tech City, USA",
                "footer_email": "info@youragency.com",
                "footer_phone": "+1 (555) 123-4567",
                "footer_linkedin": "https://linkedin.com/your-company",
                "footer_twitter": "https://twitter.com/your-company",
                "footer_logo_light": "images/logo-light.png" # Path relative to frontend
            },
            "client_logos": [
                {"name": "Client Logo 1", "image_url": "images/client-logo-1.png"},
                {"name": "Client Logo 2", "image_url": "images/client-logo-2.png"},
                {"name": "Client Logo 3", "image_url": "images/client-logo-3.png"},
                {"name": "Client Logo 4", "image_url": "images/client-logo-4.png"},
                {"name": "Client Logo 5", "image_url": "images/client-logo-5.png"}
            ],
            "ai_advantages": [
                {"title": "Unmatched Precision", "description": "AI analyzes vast datasets to pinpoint your ideal audience and predict optimal strategies with accuracy beyond human capabilities.", "icon_url": "images/icon-ai-precision.svg"},
                {"title": "Unrivaled Efficiency", "description": "Automate repetitive tasks, optimize campaigns in real-time, and scale your efforts without proportional increases in manual labor.", "icon_url": "images/icon-ai-efficiency.svg"},
                {"title": "Exponential Scale", "description": "Rapidly test, learn, and deploy campaigns across multiple channels and segments, achieving growth traditionally unattainable.", "icon_url": "images/icon-ai-scale.svg"}
            ],
            "services": [
                {"title": "AI-Driven SEO", "description": "Dominate US SERPs with AI-powered keyword research, predictive content, and technical optimization.", "icon_url": "images/icon-seo.svg"},
                {"title": "Shopify & E-commerce (AI-Enhanced)", "description": "High-converting stores with AI for personalization, dynamic pricing, and automated customer support.", "icon_url": "images/icon-shopify.svg"},
                {"title": "WordPress & AI Content", "description": "Robust WordPress sites integrating AI for content generation, optimization, and performance tracking.", "icon_url": "images/icon-wordpress.svg"},
                {"title": "Dropshipping Setup (AI-Automated)", "description": "Launch and scale your dropshipping business with AI-powered product research and fulfillment automation.", "icon_url": "images/icon-dropshipping.svg"},
                {"title": "Social Media for Business (AI-Optimized)", "description": "AI-driven content creation, targeted ads, and sentiment analysis for powerful social presence.", "icon_url": "images/icon-social-media.svg"},
                {"title": "Branding & Identity (AI-Assisted)", "description": "Craft compelling brands leveraging AI for creative inspiration and market trend analysis.", "icon_url": "images/icon-branding.svg"},
                {"title": "AI-Optimized PPC", "description": "Maximize ROI with AI-driven bidding, dynamic ad copy, and predictive audience targeting for US campaigns.", "icon_url": "images/icon-ppc.svg"},
                {"title": "AI-Powered Analytics & Reporting", "description": "Deep, actionable insights and automated reports that guide strategic decisions and predict future trends.", "icon_url": "images/icon-analytics.svg"}
            ],
            "case_studies": [
                {
                    "id": "ecom",
                    "title": "AI-Powered E-commerce Acceleration for Urban Botanicals",
                    "industry": "US Online Plant Retailer",
                    "challenge": "Urban Botanicals faced stagnant organic growth and generic customer engagement, struggling to stand out in a crowded market.",
                    "solution": "We deployed AI tools for advanced botanical keyword research and voice search optimization. We integrated an AI recommendation engine into their Shopify store for personalized shopping, and launched an AI chatbot for instant plant care advice. AI also fueled our social media content creation and targeting.",
                    "results_text": "Within 8 months, Urban Botanicals achieved a **110% increase** in qualified organic website traffic and a **65% increase** in average order value due to personalized recommendations. Their AI chatbot **reduced customer support queries by 30%**, and social media content saw a **1.5x higher engagement rate**.",
                    "results_charts_html": "<img src='images/case-study-ecom-graph.png' alt='E-commerce Growth Graph' style='max-width:100%; height:auto; margin-top:20px; border-radius:8px;'>",
                    "testimonial": "Bringing [Your Agency Name] onboard was the smartest decision we made. Their AI-driven approach to SEO utterly transformed our online visibility. We saw a dramatic increase in organic leads that were genuinely interested in our services. It's clear they're at the forefront of digital marketing with AI.",
                    "cite": "David Chen, CEO, Tech Innovations Inc. (New York, NY)",
                    "thumbnail_url": "images/case-study-ecom-thumb.jpg"
                },
                {
                    "id": "saas",
                    "title": "B2B SaaS Lead Generation with AI Insights for Nexus CRM",
                    "industry": "US Tech & Software (CRM)",
                    "challenge": "A rapidly growing B2B SaaS startup needed to generate high-quality leads for their sales team, but previous campaigns yielded low conversion rates and poor lead quality.",
                    "solution": "We designed a comprehensive lead generation strategy leveraging AI for precise audience segmentation on LinkedIn Ads and predictive lead scoring. AI tools assisted in crafting highly personalized content for nurturing sequences, and we optimized their website conversion pathways based on AI-driven user behavior analysis.",
                    "results_text": "Our AI-enhanced campaigns generated **$1.5 million in sales pipeline** within 9 months, with a **45% increase in Marketing Qualified Lead (MQL) to Sales Qualified Lead (SQL)** conversion rates. Organic leads from AI-optimized content grew by **80%**.",
                    "results_charts_html": "<img src='images/case-study-saas-graph.png' alt='SaaS Pipeline Growth Graph' style='max-width:100%; height:auto; margin-top:20px; border-radius:8px;'>",
                    "testimonial": "[Your Agency Name] revolutionized our lead acquisition. Their strategic insights and execution, particularly with AI, led directly to significant pipeline growth and a much healthier sales funnel. Their specialization in AI truly sets them apart.",
                    "cite": "Jessica Miller, Founder, Zenith Drops (Los Angeles, CA)",
                    "thumbnail_url": "images/case-study-saas-thumb.jpg"
                },
                {
                    "id": "local",
                    "title": "AI-Enhanced Local SEO Dominance for GreenThumb Landscaping",
                    "industry": "National US Home Services",
                    "challenge": "A national home services franchise struggled to improve local search visibility across its 50+ US locations, unable to rank above competitors in local map packs and organic search.",
                    "solution": "We implemented an AI-powered local SEO strategy, including automated Google My Business optimization, AI-driven localized content creation for each branch, and smart citation building. AI also helped us analyze competitor local strategies and identify untapped ranking opportunities.",
                    "results_text": "We achieved a **250% increase** in local search visibility, resulting in a **180% increase** in direct calls and direction requests from Google My Business listings. All target locations saw significant improvements in local pack rankings, driving a surge in localized inquiries.",
                    "results_charts_html": "<img src='images/case-study-local-graph.png' alt='Local SEO Visibility Graph' style='max-width:100%; height:auto; margin-top:20px; border-radius:8px;'>",
                    "testimonial": "The team at [Your Agency Name] brought unparalleled expertise to our local SEO challenge. We've seen a tangible impact on our incoming leads from every single location, all thanks to their innovative, AI-driven approach.",
                    "cite": "Robert Davis, Marketing Director, Coastal Resorts (Miami, FL)",
                    "thumbnail_url": "images/case-study-local-thumb.jpg"
                }
            ],
            "testimonials": [
                {"quote": "Bringing [Your Agency Name] onboard was the smartest decision we made. Their AI-driven approach to SEO utterly transformed our online visibility. We saw a dramatic increase in organic leads that were genuinely interested in our services. It's clear they're at the forefront of digital marketing with AI.", "client_name": "David Chen", "client_title_location": "CEO, Tech Innovations Inc. (New York, NY)", "photo_url": "images/client-testimonial-sarah.jpg"},
                {"quote": "As a dropshipper, efficiency is everything. [Your Agency Name]s AI automation for product sourcing and customer service has been invaluable. It's like having a 24/7 team working for us, allowing us to focus on scaling. Their specialization in AI truly sets them apart.", "client_name": "Jessica Miller", "client_title_location": "Founder, Zenith Drops (Los Angeles, CA)", "photo_url": "images/client-testimonial-jessica.jpg"},
                {"quote": "We needed a fresh, data-driven approach to our social media, and [Your Agency Name] delivered. Their use of AI for content creation and audience targeting resulted in our most engaging campaigns to date. We're consistently seeing higher conversion rates from our social efforts now.", "client_name": "Robert Davis", "client_title_location": "Marketing Director, Coastal Resorts (Miami, FL)", "photo_url": "images/client-testimonial-robert.jpg"}
            ]
        }

        # Insert global settings
        gs = initial_data["global_settings"]
        cursor.execute(
            "INSERT INTO global_settings (id, hero_typed_words, hero_sub_headline, hero_video_url, footer_address, footer_email, footer_phone, footer_linkedin, footer_twitter, footer_logo_light) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (1, gs["hero_typed_words"], gs["hero_sub_headline"], gs["hero_video_url"], gs["footer_address"], gs["footer_email"], gs["footer_phone"], gs["footer_linkedin"], gs["footer_twitter"], gs["footer_logo_light"])
        )

        # Insert client logos
        for logo in initial_data["client_logos"]:
            cursor.execute("INSERT INTO client_logos (name, image_url) VALUES (?, ?)", (logo["name"], logo["image_url"]))

        # Insert AI advantages
        for adv in initial_data["ai_advantages"]:
            cursor.execute("INSERT INTO ai_advantages (title, description, icon_url) VALUES (?, ?, ?)", (adv["title"], adv["description"], adv["icon_url"]))

        # Insert services
        for service in initial_data["services"]:
            cursor.execute("INSERT INTO services (title, description, icon_url) VALUES (?, ?, ?)", (service["title"], service["description"], service["icon_url"]))

        # Insert case studies
        for cs in initial_data["case_studies"]:
            cursor.execute(
                "INSERT INTO case_studies (id, title, industry, challenge, solution, results_text, results_charts_html, testimonial, cite, thumbnail_url) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (cs["id"], cs["title"], cs["industry"], cs["challenge"], cs["solution"], cs["results_text"], cs["results_charts_html"], cs["testimonial"], cs["cite"], cs["thumbnail_url"])
            )

        # Insert testimonials
        for test in initial_data["testimonials"]:
            cursor.execute(
                "INSERT INTO testimonials (quote, client_name, client_title_location, photo_url) VALUES (?, ?, ?, ?)",
                (test["quote"], test["client_name"], test["client_title_location"], test["photo_url"])
            )
        db.commit()
    print("Database initialized and populated with data.")


# --- API Endpoints (Remains the same) ---

@app.route('/api/global-settings', methods=['GET'])
def get_global_settings():
    db = get_db()
    cursor = db.cursor()
    cursor.execute("SELECT * FROM global_settings WHERE id = 1")
    settings = cursor.fetchone()
    if settings:
        settings_dict = dict(settings)
        # Safely parse hero_typed_words
        try:
            settings_dict['hero_typed_words'] = json.loads(settings_dict['hero_typed_words'])
        except json.JSONDecodeError:
            settings_dict['hero_typed_words'] = [] # Default to empty list if invalid JSON
        return jsonify(settings_dict)
    return jsonify({"error": "Global settings not found"}), 404

@app.route('/api/client-logos', methods=['GET'])
def get_client_logos():
    db = get_db()
    cursor = db.cursor()
    cursor.execute("SELECT * FROM client_logos")
    logos = [dict(row) for row in cursor.fetchall()]
    return jsonify(logos)

@app.route('/api/ai-advantages', methods=['GET'])
def get_ai_advantages():
    db = get_db()
    cursor = db.cursor()
    cursor.execute("SELECT * FROM ai_advantages")
    advantages = [dict(row) for row in cursor.fetchall()]
    return jsonify(advantages)

@app.route('/api/services', methods=['GET'])
def get_services():
    db = get_db()
    cursor = db.cursor()
    cursor.execute("SELECT * FROM services")
    services = [dict(row) for row in cursor.fetchall()]
    return jsonify(services)

@app.route('/api/case-studies', methods=['GET'])
def get_case_studies():
    db = get_db()
    cursor = db.cursor()
    cursor.execute("SELECT * FROM case_studies")
    case_studies = [dict(row) for row in cursor.fetchall()]
    return jsonify(case_studies)

@app.route('/api/case-studies/<string:case_id>', methods=['GET'])
def get_single_case_study(case_id):
    db = get_db()
    cursor = db.cursor()
    cursor.execute("SELECT * FROM case_studies WHERE id = ?", (case_id,))
    case_study = cursor.fetchone()
    if case_study:
        return jsonify(dict(case_study))
    return jsonify({"error": "Case study not found"}), 404

@app.route('/api/testimonials', methods=['GET'])
def get_testimonials():
    db = get_db()
    cursor = db.cursor()
    cursor.execute("SELECT * FROM testimonials")
    testimonials = [dict(row) for row in cursor.fetchall()]
    return jsonify(testimonials)

# --- NEW: Simple UI for Backend Global Settings ---

@app.route('/admin/settings', methods=['GET', 'POST'])
def admin_settings():
    db = get_db()
    cursor = db.cursor()

    if request.method == 'POST':
        # Get data from the form
        hero_typed_words_input = request.form.get('hero_typed_words', '').strip()
        hero_sub_headline = request.form.get('hero_sub_headline', '')
        hero_video_url = request.form.get('hero_video_url', '')
        footer_address = request.form.get('footer_address', '')
        footer_email = request.form.get('footer_email', '')
        footer_phone = request.form.get('footer_phone', '')
        footer_linkedin = request.form.get('footer_linkedin', '')
        footer_twitter = request.form.get('footer_twitter', '')
        footer_logo_light = request.form.get('footer_logo_light', '')

        # Process hero_typed_words for saving to DB
        if hero_typed_words_input:
            # Split by comma, strip whitespace from each word, and filter out empty strings
            words_list = [word.strip() for word in hero_typed_words_input.split(',') if word.strip()]
            hero_typed_words_db_format = json.dumps(words_list)
        else:
            hero_typed_words_db_format = json.dumps([]) # Save an empty JSON array if input is empty

        # Update the database
        cursor.execute(
            """
            UPDATE global_settings SET
                hero_typed_words = ?,
                hero_sub_headline = ?,
                hero_video_url = ?,
                footer_address = ?,
                footer_email = ?,
                footer_phone = ?,
                footer_linkedin = ?,
                footer_twitter = ?,
                footer_logo_light = ?
            WHERE id = 1
            """,
            (
                hero_typed_words_db_format, hero_sub_headline, hero_video_url,
                footer_address, footer_email, footer_phone,
                footer_linkedin, footer_twitter, footer_logo_light
            )
        )
        db.commit()
        return redirect(url_for('admin_settings')) # Redirect to GET to show updated data

    # For GET request, fetch current settings to pre-fill the form
    cursor.execute("SELECT * FROM global_settings WHERE id = 1")
    settings = cursor.fetchone()
    if settings:
        settings_dict = dict(settings)
        # Safely parse hero_typed_words from DB to string for the form
        try:
            parsed_words = json.loads(settings_dict.get('hero_typed_words', '[]'))
            settings_dict['hero_typed_words'] = ", ".join(parsed_words)
        except (json.JSONDecodeError, TypeError):
            settings_dict['hero_typed_words'] = "" # Default to empty string if invalid
    else:
        settings_dict = {} # Empty dict if no settings found (shouldn't happen after init_db)

    return render_template('admin_settings.html', settings=settings_dict)


# Run the database initialization when the app starts
with app.app_context():
    init_db()

if __name__ == '__main__':
    app.run(debug=True, port=5000)